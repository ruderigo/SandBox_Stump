# µReticulum Logging
# Lightweight, no threading, stdout only

import time

LOG_NONE     = -1
LOG_CRITICAL = 0
LOG_ERROR    = 1
LOG_WARNING  = 2
LOG_NOTICE   = 3
LOG_INFO     = 4
LOG_VERBOSE  = 5
LOG_DEBUG    = 6
LOG_EXTREME  = 7

loglevel = LOG_NOTICE

_level_names = {
    0: "CRIT", 1: "ERR ", 2: "WARN",
    3: "NOTE", 4: "INFO", 5: "VERB",
    6: "DBG ", 7: "XTRA",
}


# Bounded in-memory ring of recent log lines, for the optional HTTP monitor.
_LOG_RING = []
_LOG_RING_MAX = 100


def get_log_ring():
    return _LOG_RING


def sl(level):
    """True if `level` would be logged right now (reference RNS: RNS.sl()).

    Call this to gate expensive log-string building on hot paths. It reads the
    module global at call time, so a runtime set_loglevel() takes effect —
    unlike a cached `loglevel >= LOG_DEBUG` snapshot taken at import, which
    freezes before config raises the level. Import it directly (`from .log
    import sl`): `urns.log` as a package attribute is the log *function*, not
    this module, because urns/__init__.py re-exports it.
    """
    return loglevel >= level


def log(msg, level=LOG_NOTICE):
    if loglevel >= level:
        try:
            ln = _level_names.get(level, "????")
            line = "[%d][%s] %s" % (time.time(), ln, str(msg))
            print(line)
            _LOG_RING.append(line)
            if len(_LOG_RING) > _LOG_RING_MAX:
                _LOG_RING.pop(0)
        except:
            pass


def set_loglevel(level):
    global loglevel
    loglevel = level


def trace_exception(e):
    import sys
    sys.print_exception(e)
